import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class PasswordStrength {

	public static void main(String[] args) throws IOException {
		
		//boolean found = false;
		boolean passMatch = false;
		String line;
		String lines;
		Scanner input = new Scanner(System.in);
		
		BufferedReader brDictionary = new BufferedReader(new FileReader("C:/Users/Sol/Desktop/dictionary.txt"));
		BufferedReader brDictionary2 = new BufferedReader(new FileReader("C:/Users/Sol/Desktop/dictionary.txt"));
		
		System.out.println("Enter a password to determine its strength: ");
		String password = input.nextLine();
		
		if(passMatch==false){//if the password strength hasn't been found
			while(((line=brDictionary.readLine()) != null) && (passMatch==false)){
				String word = line;
				
				if(password.equals(word)){//if the dictionary word is exactly the same as the password
					passMatch = true;
					System.out.println("Your password strength is weak.");
					System.exit(0);
				}
			}//end of while loop looking at dictionary words
			
			ArrayList<String> dictionary = new ArrayList<String>();
			while((lines=brDictionary2.readLine()) != null){
				dictionary.add(lines);
			}//end of while loop to create arraylist of dictionary words
			
			for(int i=0; i<dictionary.size(); i++){
				String word = dictionary.get(i).toString();
				
				if(password.contains(word)){//if the dictionary word is in the password but not exactly the password
					passMatch = true;
					System.out.println("Your password strength is moderate.");
					System.exit(0);
				}
			}//end of for loop (goes through each dictionary word and see if it is contained within the password)
			
			System.out.println("Your password strength is strong.");
		}//end of if(found) loop
		
		brDictionary.close();
		brDictionary2.close();
		input.close();
	}

}
