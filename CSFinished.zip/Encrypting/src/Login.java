import java.io.BufferedReader;
//import java.io.File;
//import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Scanner;

public class Login {
	public static void main(String[] args) throws IOException {
		dothething();
	}
	
	public static void dothething() throws IOException{
		//Scanner scan = new Scanner (new File());
		Scanner input = new Scanner(System.in);
		
		BufferedReader br = new BufferedReader(new FileReader("C:/Users/Sol/Desktop/pass.txt"));	
		
		System.out.println("username: ");
		String userUsername = input.nextLine();
		
		System.out.println("password: ");
		String userPassword = input.nextLine();
		
		String userPasswordHash = JavaMD5Hash.md5(userPassword); //hashes the user's password input
		
		String line;
		String username = "";
		String password = "";
		boolean found = false;
		
		while ((line=br.readLine()) != null) {
			if(line.startsWith(userUsername)){
				String[] parts = line.split(" ");
				username = parts[0];
				
				if(username.equals(userUsername)){
					password = parts[1];
					found = true;
					break;	
				}
			}else{
				found = false;
			}
		}
		
		if(found){
			if(userUsername.equals(username) && userPasswordHash.equals(password)){
				System.out.println("You are now logged in.");
			}else{
				System.out.println("Login failed.");
			}
		}else{
			System.out.println("Username doesn't exist.");
		}
		
		
		br.close();
		input.close();
	}
}
