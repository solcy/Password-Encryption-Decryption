
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Permute {

    public static void main(String[] args) throws IOException {
    	String[] chars = new String[] {"0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "@", "#", "$", "%", "&", "-"};
        
    	Scanner input = new Scanner(System.in);
		
		BufferedReader br = new BufferedReader(new FileReader("C:/Users/Sol/Desktop/pass.txt"));
		BufferedReader brDictionary = new BufferedReader(new FileReader("C:/Users/Sol/Desktop/dictionary.txt"));
		BufferedReader brWords = new BufferedReader(new FileReader("C:/Users/Sol/Desktop/dictionary.txt"));
		
		System.out.println("What username password do you want to crack? ");
		String userUsername = input.nextLine();
		
		String line;
		String lines;
		String username = "";
		String password = "";
		boolean found = false;
		boolean passMatch = false;
		boolean passFound = false;
		long startTime = System.currentTimeMillis();
		
		while ((line=br.readLine()) != null) {
			if(line.startsWith(userUsername)){
				String[] parts = line.split(" ");
				username = parts[0];
				
				if(username.equals(userUsername)){
					password = parts[1];
					found = true;
					break;	
				}
			}else{
				found = false;
			}
		}//end of while loop that looks for username match and it's hashed pw
		
		
		if(found && passMatch==false){//if the username is found, search for a pw match to a dictionary word
			while ( ((line=brWords.readLine()) != null) && (passMatch==false)) {
				String word = line;
				String hashedWord = JavaMD5Hash.md5(word); 
				
				if(hashedWord.equals(password)){
					long endTime = System.currentTimeMillis();
        			long totalTime = (endTime - startTime)/1000 + 1;
					System.out.println("The password for " + userUsername + " is " + word);
					System.out.println("It took " + totalTime + " seconds to crack.");
					passMatch = true;
				}
			}
		}//end of if(found) loop
		
		
		ArrayList<String> dictionary = new ArrayList<String>();
		while((lines=brDictionary.readLine()) != null){
			dictionary.add(lines);
		}
		
		if(found && passMatch==false){
			String realPass = "";
			String word = "";
			for(int i=2; i<=16; i++){//i<=16
				for(int q=0; q<dictionary.size(); q++){
					word = dictionary.get(q).toString();
			
					realPass = PasswordGenerator.possibleStrings(i, chars,"", word, password, "", passFound, startTime); 
					if(!(realPass.equals(""))){
						System.out.println(realPass);
						passMatch = true;
					}
				}
			}
		} 
		
		if(!found){
			System.out.println("Username doesn't exist.");
		}
		System.out.print("Finished");
        
		input.close();
        br.close();
        brDictionary.close();
        brWords.close();
        
    }

} class PasswordGenerator {

    public static String possibleStrings(int maxLength, String[] chars, String currString, String word, String passHash, String cracked, boolean passFound, long startTime) {
       
    	// If the current string has reached it's maximum length
    	if(passFound==false){
	    	if(currString.length() == maxLength) {
	        	if(currString.contains("-")){
	        		int counter = 0;
	        		boolean duplicates = false;
	        		
		        	for(int i=0; i<currString.length(); i++ ) {//searches for duplicates
		        	    if( currString.charAt(i) == '-' ) {
		        	        counter++;
		        	    } 
		        	    for(int j=0; j<currString.length(); j++){
		        	    	if((currString.charAt(i) == currString.charAt(j)) && (j!=i)) {
		        	    		duplicates = true;
		        	    	} 
		        	    }
		        	}//end of for loops
		        	
		        	
		        	
		        	if(counter==1 && duplicates==false){
			        	currString = currString.replace("-", word);
		        		String hashed = JavaMD5Hash.md5(currString);//write to currString to file with its hash	
		        		
		        		
		        		if(hashed.equals(passHash)){
		        			cracked = currString;
		        			passFound = true;
		        			long endTime = System.currentTimeMillis();
		        			long totalTime = (endTime - startTime)/1000 + 1;
		        			System.out.println("The password is: "  + cracked);
		        			System.out.println("It took " + totalTime + " seconds to crack.");
		        			System.exit(0);
		        		}
		        	}
	        	}
	        	
	        // Else add each letter from the array to new strings and process these new strings again
	        } else {
	            for(int i = 0; i < chars.length; i++) {
	                String oldCurrString = currString; //same value
	                currString += chars[i]; //adds one char to currString
	                possibleStrings(maxLength,chars,currString, word, passHash, "", passFound, startTime);
	                currString = oldCurrString;
	            }
	        }
    	}
    
    return cracked;
    }
}